#include <functions.h>

int main(){
    param data;
    VideoCapture cap("./img/Image_%04d.jpg");
    clock_t begin = clock();
    Mat frame;
    int total = 0, processed = 0;
    while(true){
        cap >> frame;
        if(frame.empty() || waitKey(1)==27)
            break;
        data = find_parameters(frame);
        if(data.desc1!=0 && data.desc2!=0 && data.desc3!=0 && data.desc4!=0 && data.desc5!=0){
            // USE DATA DESCRIPTORS HERE
            cout<<endl<<endl;
            cout<<"Image = "<<total<<endl;
            cout<<"Desc1 = "<<data.desc1<<endl;
            cout<<"Desc2 = "<<data.desc2<<endl;
            cout<<"Desc3 = "<<data.desc3<<endl;
            cout<<"Desc4 = "<<data.desc4<<endl;
            cout<<"Desc5 = "<<data.desc5<<endl;
            cout<<endl<<endl;
            processed++;
        }
        total++;
    }
    clock_t end = clock();
    cout<<endl<<endl;
    cout<<"================================================"<<endl;
    cout<<"TOTAL IMAGES     = "<<total<<endl;
    cout<<"PROCESSED IMAGES = "<<processed<<endl;
    cout<<"SKIPPED IMAGES   = "<<total-processed<<endl;
    cout<<"TOTAL EXEC TIME  = "<< double(end - begin) / CLOCKS_PER_SEC<<endl;
    cout<<endl<<endl<<"----- END OF PROGRAM -----"<<endl<<endl;
    return 0;
}
