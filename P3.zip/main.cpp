#include <functions.h>

int main(){
    param data;
    VideoCapture cap("./img/Image_%04d.jpg");
    Mat frame;
    int name = 0;
    while(cap.isOpened()){
        cap >> frame;
        data = find_parameters(frame);
        if(data.desc1!=0 && data.desc2!=0 && data.desc3!=0 && data.desc4!=0){
            // USE DATA DESCRIPTORS HERE
            cout<<endl<<endl;
            cout<<"Image = "<<name<<endl;
            cout<<"Desc1 = "<<data.desc1<<endl;
            cout<<"Desc2 = "<<data.desc2<<endl;
            cout<<"Desc3 = "<<data.desc3<<endl;
            cout<<"Desc4 = "<<data.desc4<<endl;
            cout<<endl<<endl;
        }
        name++;
    }
    return 0;
}
